// Task 0 (Building your first query)

db.todo.aggregate([
    // TODO: Write your query here
]);
