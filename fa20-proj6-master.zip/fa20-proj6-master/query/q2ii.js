// Task 2ii

db.todo.aggregate([
    // TODO: Write your query here
]);