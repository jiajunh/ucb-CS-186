// Task 2iii

db.todo.aggregate([
    // TODO: Write your query here
]);