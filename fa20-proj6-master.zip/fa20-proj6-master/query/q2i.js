// Task 2i

db.todo.aggregate([
    // TODO: Write your query here
]);