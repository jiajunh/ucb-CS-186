// Task 1iv

db.todo.aggregate([
    // TODO: Write your query here
]);