package edu.berkeley.cs186.database.categories;

public interface Proj3Part2Tests extends ProjTests  { /* category marker */ }