package edu.berkeley.cs186.database.categories;

public interface Proj4Tests extends ProjTests  { /* category marker */ }