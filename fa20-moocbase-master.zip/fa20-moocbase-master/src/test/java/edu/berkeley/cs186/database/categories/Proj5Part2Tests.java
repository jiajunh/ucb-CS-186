package edu.berkeley.cs186.database.categories;

public interface Proj5Part2Tests extends ProjTests  { /* category marker */ }